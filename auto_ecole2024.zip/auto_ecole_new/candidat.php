<!DOCTYPE html>
<html>
<head>
	<title>Authentification</title>
	<meta charset="utf-8">
</head>
<body>
<center>
	<?php
	require_once ("vue/vue.candidat.php");
	?>
</center>
</body>
</html>