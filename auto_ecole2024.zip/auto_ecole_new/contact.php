<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Devis personnalisé</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>

<body>

  <nav class="navbar navbar-expand-lg bg-body-tertiary">
    <div class="container-fluid">
      <a class="navbar-brand" href="#"><img src="images/images.png" height="150 px"></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Qui sommmes nous ?</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="index.php">Nos Formules</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="contact.php">Devis personnalisé</a>
          </li>
          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="gestion_connexion.php">Espace Client</a>
          </li>
          </form>
      </div>
    </div>
  </nav>

  <div style="background-color: #FF5733; text-align: center; color: white; font-size: 20px;">
    <p style="padding: 35px"> RECEVOIR UN DEVIS PERSONNALISÉ </p>
  </div>

  <p style="text-align:center;">Renseignez les champs et nous vous contacterons dans les meilleurs délais !</p>


  <div style="padding:50px;">
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Prenom</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Prenom">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Nom</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Nom">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Ville</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Ville">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Code postal</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Code Postal">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Email</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="name@example.com">
    </div>
    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Téléphone</label>
      <input type="email" class="form-control" id="exampleFormControlInput1" placeholder="Téléphone">
    </div>

    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Quel type de formation vous intéresse ?</label>
      <select class="form-select" aria-label="Default select example">
        <option selected>type de formation</option>
        <option value="1">Formule traditionnel </option>
        <option value="2">Formule accompagné</option>
      </select>
    </div>

    <div class="mb-3">
      <label for="exampleFormControlInput1" class="form-label">Vous souhaitez effectuer votre formation?</label>
      <select class="form-select" aria-label="Default select example">
        <option selected>choix de formation</option>
        <option value="1">En boite Manuelle</option>
        <option value="2">En boite automatique</option>
      </select>
    </div>
  </div>
  <form class="row mx-auto" method="post" action="envoi_message.php">
    <div class="mb-3">
      <div class="form-check">
        <input class="form-check-input" type="checkbox" value="" id="invalidCheck2" required>
        <label class="form-check-label" for="invalidCheck2">
          Accepter les termes et conditions
        </label>
      </div>
    </div>
    <div style="text-align: center;">
      <button class="btn btn-warning" type="submit"> Envoyer</button>
    </diV>
  </form>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>

</body>

</html>