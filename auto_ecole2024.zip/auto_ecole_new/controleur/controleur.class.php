<?php
	require_once("modele/modele.class.php"); 
	class Controleur {
		private $unModele ; 

		public function __construct (){
			$this->unModele = new Modele (); 
		}

		public function verifConnexion ($email, $mdp){
			//controler les donnees 
			if(filter_var($email,FILTER_VALIDATE_EMAIL)){

			//appel du modele pour récuperer l'user 
			//$mdp = md5($mdp); 
			//$mdp = sha1($mdp);
		
			//var_dump($gsel);
			//echo $gsel['nb'];

			$unUser = $this->unModele->verifConnexion($email, $mdp);
			return $unUser;
		}
		else{

			return null;
		}
		}

		
		public function verifConnexion2 ($email, $mdp){
			//controler les donnees 
			if(filter_var($email,FILTER_VALIDATE_EMAIL)){

			//appel du modele pour récuperer l'user 
			//$mdp = md5($mdp); 
			//$mdp = sha1($mdp);
		
			//var_dump($gsel);
			//echo $gsel['nb'];

			$unUser = $this->unModele->verifConnexion2($email, $mdp);
			return $unUser;
		}
		else{

			return null;
		}
		}

		/**************Gestion des candidats *************************/
        public function selectAllCandidat(){
            return $this->unModele->selectAllCandidat();
        }

		public function insertCandidat ($tab){
            $this->unModele->insertCandidat($tab);
        }
		
		public function selectAllMoniteur(){
            return $this->unModele->selectAllMoniteur();
        }
		public function insertMoniteur ($tab){
            $this->unModele->insertCandidat($tab);
        }

		public function selectAllVehicule(){
			return $this->unModele->selectAllVehicule();
		}

		public function insertVehicule ($tab){
            $this->unModele->insertVehicule($tab);
        }

		public function deleteVehicule ($idvehicule){
            $this->unModele->deleteVehicule($idvehicule);
        }

		public function selectAllLecon(){
			return $this->unModele->selectAllLecon();
		}

		public function selectAllPlanning(){
			return $this->unModele->selectAllPlanning();
		}
		
        public function insertPlanning ($tab){
            $this->unModele->insertPlanning($tab);
        }

		public function deletePlanning ($idplanning){
            $this->unModele->deletePlanning($idplanning);
        }
	}
?>