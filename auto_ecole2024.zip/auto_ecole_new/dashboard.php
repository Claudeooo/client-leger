<?php
session_start() ;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tableau de bord</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body style="background-image: url('images/fond2.jpg');">
    


<?php
include('layout/navbar-admin.php');
?>

    <center>
    
    <h4><?php echo "Bienvenue ".$_SESSION['nom']; ?> <h4><br><br>
    <h5> Mes information </h5><br><br>
    <div style="background-color:#B8B8B8 ; border:1px solid black; border-radius:35px;">  
    <p> <br>
        Nom : <?php echo $_SESSION['nom'] ?><br><br>
        Prenom : <?php echo  $_SESSION['prenom'] ?><br><br>
        Email : <?php echo $_SESSION['mail'] ?><br><br>
        Téléphone : <?php echo $_SESSION['tel'] ?><br><br>
      </p>
    </div>
    </center>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>