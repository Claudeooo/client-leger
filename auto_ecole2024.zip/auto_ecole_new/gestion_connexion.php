<?php
    session_start();
	require_once("controleur/controleur.class.php"); 
	//instanciation du controleur 
	$unControleur = new Controleur (); 
?>
<!DOCTYPE html>
<html>
<head>
	<title>Authentification</title>
	<meta charset="utf-8">
</head>
<body>
<center>
	<h1> Authentification </h1>
	<?php
	require_once ("vue/login.php");
	if(isset($_POST['Valider']))
	{
		$email = $_POST["email"]; 
		$mdp = $_POST['mdp']; 
		if ($_POST['type_user'] == "moniteur"){	
	    	$unUser = $unControleur->verifConnexion($email, $mdp);
   		}else {
   			$unUser = $unControleur->verifConnexion2($email, $mdp);
   		}
	   
	   //var_dump($unUser);

		if ($unUser!=null && $unUser['type_user']=='moniteur'){

            $_SESSION['nom'] = $unUser['NOM'];
            $_SESSION['prenom'] = $unUser['PRENOM'];
            $_SESSION['mail'] = $unUser['EMAIL'];
            $_SESSION['tel'] = $unUser['NUMERO_TELEPHONE'];
			header('Location:dashboard.php');
		}else
			 if($unUser != null && $unUser['type_user']=='candidat'){
				$_SESSION['nom'] = $unUser['NOM'];
				$_SESSION['prenom'] = $unUser['PRENOM'];
				$_SESSION['mail'] = $unUser['EMAIL'];
				$_SESSION['tel'] = $unUser['NUMERO_TELEPHONE'];
			header('Location:dashboard2.php');
		}else{
			Echo"vérifiez vos informations";
		}
		
	}
	?>
</center>
</body>
</html>