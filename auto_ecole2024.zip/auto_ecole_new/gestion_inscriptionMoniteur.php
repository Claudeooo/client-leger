
<?php
session_start();
require_once ("vue/vue.inscriptionmoniteur.php");
require_once("controleur/controleur.class.php"); 
$unControleur = new Controleur (); 
if(isset($_POST['Valider'])){
    $unControleur->insertMoniteur($_POST);
    session_destroy(); 
    unset($_SESSION['email']);
    
    header('Location: gestion_connexion.php');
   }

?>
