<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Acceuil</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

</head>
<body>
    
<nav class="navbar navbar-expand-lg bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="#"><img src="images/images.png" height="150 px" ></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#def">Qui sommmes nous ?</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="#formules">Nos Formules</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contact.php">Devis personnalisé</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="contact.php">Contactez nous</a>
        </li>
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="gestion_connexion.php">Espace Client</a>
        </li>
      </form>
    </div>
  </div>
</nav>

 <img src="images/banner.jpg" height="450 px" width="1480 px">
 
 <div id="def">
 <div style="background-color: #FF5733; text-align: center; color: white; font-size: 20px;">
    <p style="padding: 35px"> VOTRE PERMIS RAPIDE ET ACCESSIBLE ! </p>
</div>

 
<h3 style="color:#FF5733; text-align:center;" >Notre mission : vous rendre la route accessible ! </h3>
<p style="padding:50px;">
Ainsi notre équipe de formateurs professionnels triés sur le volet vous accompagne pour le passage de votre permis auto ou moto.<br>
Notre école de conduite vous offre et vous réserve un accueil et un cadre de travail agréable avec une équipe de professionnels dynamiques et passionnés par leur métier. School Conduite met à votre disposition toutes les dernières technologies pour vous mettre en situation réelle d’examen au code et également à votre disposition un simulateur dernière génération pour vous préparer au mieux à votre future formation pratique.
</p>


<h3 style="color:#FF5733; text-align:center;">Votre réussite est notre satisfaction ! </h3>
<p style="padding:50px;">
Nous sommes spécialistes des stages accélérés afin de répondre à un besoin urgent.
Nous effectuons le permis auto sur boîte manuelle ou automatique en fonction de vos besoins.
Différentes formules vous sont proposées pour le passage de votre permis :
Vous aurez également une traçabilité de tous vos résultats que ce soit en salle de code, sur internet, ou sur le simulateur en un clic.
Tout cela pour vous permettre de mieux progresser.
School Conduite vous donne les moyens d’être un véritable centre de formation.
Parce que nous savons également qu’il n’est pas toujours facile de se libérer pour une formation à la conduite, chez School Conduite nous avons pensé à tout et nous vous facilitons donc la vie en vous offrant des créneaux accessibles à tous.
</p>
</div>


<div id="formules" style="background-color: black; text-align: center; color: white; font-size: 20px;">
 <p style="padding: 35px">Decouvrez nos formules </p>
</div>

<p style="text-align:center;"> FORMATIONS PERMIS B TRADITIONNEL </p>

<div class="container text-center">
  <div class="row">
    <div class="col">
    <div  style="background-color: black">
        <p style="color:white;"> FORMULE 20H <br> 1550€ <br>
        Boite manuelle</p>
<ul style="color:white">
    <li>Gestion administratives</li>
    <li>Accès bar à code (6 mois)</li>
    <li>Professeur dispo code sur RDV</li>
    <li>Kit pédagogique : livret d’apprentissage, livret de code</li>
    <li>Interface pédagogique (Pack Web digital pour le code)</li>
    <li>20 heures de conduite dont 4 heures sur simulateur</li>
    <li>Simulateur en illimité (1 an)</li>
    <li>Un suivi pédagogique de qualité</li>
    <br>
    </div>
    </div>
    <div class="col">
    <div style="background-color: black">
        <p style="color:white;"> FORMULE 30H <br> 1950€ <br> Boite manuelle</p>
<ul style="color:white">
<li>Gestion administratives </li>
<li>Accès bar à code (6 mois)</li>
<li>Professeur dispo code sur RDV</li>
<li>Kit pédagogique : livret d’apprentissage, livret de code</li>
<li>Interface pédagogique (Pack Web digital pour le code)</li>
<li>30 heures de conduite dont 4 heures sur simulateur</li>
<li>Simulateur en illimité (1 an)</li>
<li>Un suivi pédagogique de qualité</li>
</ul>
    </div>
    </div>
    <div class="col">
    <div  style="background-color: black">
        <p style="color:white;"> FORMULE accompagnE <br> 1560€ <br>  Boite manuelle</p>

<ul style="color:white">
<li>Gestion administratives</li>
<li>Accès bar à code (6 mois)</li>
<li>Professeur dispo code sur RDV</li>
<li>Kit pédagogique : livret d’apprentissage, livret de code</li>
<li>Interface pédagogique (Pack Web digital pour le code)</li>
<li>20 heures de conduite dont 4 heures sur simulateur</li>
<li>Simulateur en illimité (1 an)</li>
<li>3rdv pédagogiques (rdv préalable, 1er rdv pédagogique, 2e rdv pédagogique)</li>
<li>Un suivi pédagogique de qualité</li>
</ul>
    </div>
    </div>
  </div>
</div>

<button type="button" style="margin-left:700px;" class="btn btn-dark">Faire un devis</button><br><br>

<h3 style="text-align:center;">FORMATIONS PERMIS B AUTOMATIQUE</h3>
<h4 style="color:#FF5733; text-align:center;">90% DE TAUX DE RÉUSSITE </h4>

<div class="container text-center">
  <div class="row">
    <div class="col">
    <div  style="background-color: black">
        <p style="color:white;"> FORMULE 20H <br> 1550€ <br>
        Boite automatique</p>
<ul style="color:white">
    <li>Gestion administratives</li>
    <li>Accès bar à code (6 mois)</li>
    <li>Professeur dispo code sur RDV</li>
    <li>Kit pédagogique : livret d’apprentissage, livret de code</li>
    <li>Interface pédagogique (Pack Web digital pour le code)</li>
    <li>20 heures de conduite dont 4 heures sur simulateur</li>
    <li>Simulateur en illimité (1 an)</li>
    <li>Un suivi pédagogique de qualité</li>
    <br>
    </div>
    </div>
    <div class="col">
    <div style="background-color: black">
        <p style="color:white;"> FORMULE 30H <br> 1750€ <br> Boite automatique</p>
<ul style="color:white">
<li>Gestion administratives </li>
<li>Accès bar à code (6 mois)</li>
<li>Professeur dispo code sur RDV</li>
<li>Kit pédagogique : livret d’apprentissage, livret de code</li>
<li>Interface pédagogique (Pack Web digital pour le code)</li>
<li>30 heures de conduite dont 4 heures sur simulateur</li>
<li>Simulateur en illimité (1 an)</li>
<li>Un suivi pédagogique de qualité</li>
</ul>
    </div>
    </div>
    <div class="col">
    <div  style="background-color: black">
        <p style="color:white;"> FORMULE accompagnE <br> 2160€ <br>  Boite automatique</p>

<ul style="color:white">
<li>Gestion administratives</li>
<li>Accès bar à code (6 mois)</li>
<li>Professeur dispo code sur RDV</li>
<li>Kit pédagogique : livret d’apprentissage, livret de code</li>
<li>Interface pédagogique (Pack Web digital pour le code)</li>
<li>20 heures de conduite dont 4 heures sur simulateur</li>
<li>Simulateur en illimité (1 an)</li>
<li>3rdv pédagogiques (rdv préalable, 1er rdv pédagogique, 2e rdv pédagogique)</li>
<li>Un suivi pédagogique de qualité</li>
</ul>
    </div>
    </div>
  </div>
</div>
<button type="button" style="margin-left:700px;" class="btn btn-dark">Faire un devis</button><br><br>

<div style="text-align:center;"><br>
<h5> NE PERDEZ PLUS DE TEMPS, CONTACTEZ NOUS ! </h5><br>
<button type="button" class="btn btn-warning" href="contact.php">Contactez-nous !</button>
</di>


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>