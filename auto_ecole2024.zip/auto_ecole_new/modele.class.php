
<?php
	class Modele {
		private $unPDO ; //php data object 

		public function   __construct(){
			try{
$this->unPDO = new PDO("mysql:host=localhost;dbname=auto_ecole_24","root",""); 
			}
			catch (PDOException $exp){
echo "Erreur de connexion a la bdd : "; 
echo $exp->getMessage(); 
			}
		}
	public function verifConnexion ($email, $mdp)
	{

		//$requete ="select * from user where email ='".$email."' and mdp ='".$mdp."';" ;

		$requete = "select * from moniteur where EMAIL =:email and mdp = :mdp ; "; 
		$donnees = array(":email"=>$email, 
			":mdp"=>$mdp); 

		//preparattion de la requete 
		$select = $this->unPDO->prepare($requete);
		
		//execution de la requete 
		$select->execute ($donnees); //envoi tableau des données  
		//extraite le resultat 
		$unUser = $select->fetch ();
		return $unUser;
       
	}

    public function verifConnexion2 ($email, $mdp)
	{

		$requete = "select * from candidat where EMAIL =:email and mdp = :mdp ; "; 
		$donnees = array(":email"=>$email, 
			":mdp"=>$mdp); 

		//preparattion de la requete 
		$select = $this->unPDO->prepare($requete);
		
		//execution de la requete 
		$select->execute ($donnees); //envoi tableau des données  
		//extraite le resultat
		$unUser = $select->fetch ();
		return $unUser;
       
	}
//**********************Gestion de candidat*********************************
    public function selectAllCandidat(){
        $requete = "select * from candidat ;";
        $select = $this->unPDO->prepare ($requete);
        $select->execute();
        return $select->fetchAll();
    }

    public function insertCandidat ($tab){
        $requete = "insert into candidat values (iduser, :nom, :prenom, :adresse_mail, :mdp, :type_user, :numero_telephone, 0);";
        $donnees = array( ":nom"=>$tab['nom'],
                          ":prenom"=>$tab['prenom'],
                          ":adresse_mail"=>$tab['adresse_mail'],
                          ":mdp"=>$tab['mdp'],
                          ":type_user"=>$tab['type_user'],
                          ":numero_telephone"=>$tab['numero_telephone']);
        $select = $this->unPDO->prepare($requete);
        $select->execute($donnees);
    }
//****************Gestion moniteur**************************** */
	public function selectAllMoniteur(){
        $requete = "select * from moniteur ;";
        $select = $this->unPDO->prepare ($requete);
        $select->execute();
        return $select->fetchAll();
    }
    public function insertMoniteur ($tab)
        {
            $requete ="insert into moniteur values (iduser, :nom, :prenom, :adresse_mail, :mdp, :type_user, :numero_telephone);";
            $donnees = array( ":nom"=>$tab['nom'],
                          ":prenom"=>$tab['prenom'],
                          ":adresse_mail"=>$tab['adresse_mail'],
                          ":mdp"=>$tab['mdp'],
                          ":numero_telephone"=>$tab['numero_telephone']);
            $select = $this->unPDO->prepare ($requete);                 
            $select->execute ($donnees);
        }
	
    public function selectAllVehicule(){
        $requete = "select * from vehicule ;";
        $select = $this->unPDO->prepare ($requete);
        $select->execute();
        return $select->fetchAll();
    }
    public function deleteVehicule ($idvehicule){
        $requete = "delete from vehicule where idvehicule = :idvehicule;";
        $donnees = array( ":idvehicule"=>$idvehicule);
        $select = $this->unPDO->prepare($requete);
        $select->execute($donnees);
    }
    public function insertVehicule ($tab){
        $requete = "insert into vehicule values (idvehicule, :marque, :modele, :immatriculation);";
        $donnees = array( ":marque"=>$tab['marque'],
                          ":modele"=>$tab['modele'],
                          ":immatriculation"=>$tab['immatriculation']);
        $select = $this->unPDO->prepare($requete);
        $select->execute($donnees);
    }

    public function selectAllLecon(){
        $requete = "select * from lecons ;";
        $select = $this->unPDO->prepare ($requete);
        $select->execute();
        return $select->fetchAll();
    }

    public function selectAllPlanning(){
        $requete = "select * from plannings ;";
        $select = $this->unPDO->prepare ($requete);
        $select->execute();
        return $select->fetchAll();
    }

    public function insertPlanning ($tab){
        $requete = "insert into plannings values (IDPLANNING, :idlecon, :iduser_1, :dateheurdebur, :iduser_2, :datefinheur, :etat);";
        $donnees = array(
                        ":idlecon"=>$tab['IDLECON'],
                          ":iduser_1"=>$tab['IDUSER_1'],
                          ":dateheurdebur"=>$tab['DATEHEURDEBUR'],
                          ":iduser_2"=>$tab['IDUSER_2'],
                          ":datefinheur"=>$tab['DATEFINHEUR'],
                          ":etat"=>$tab['ETAT']);
        $select = $this->unPDO->prepare($requete);
        $select->execute($donnees);
    }

    public function deletePlanning ($idplanning){
        $requete = "delete from plannings where idplanning = :idplanning;";
        $donnees = array( ":idplanning"=>$idplanning);
        $select = $this->unPDO->prepare($requete);
        $select->execute($donnees);
    }
	}
?>