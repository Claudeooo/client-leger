
<?php
require_once ("vue/vue.planning.php");

if(isset($_POST['Valider'])){
    $unControleur->insertPlanning ($_POST);
   }

   if(isset($_GET['action']) && isset($_GET['idplanning'])){
    $action = $_GET['action'];
    $idplanning = $_GET['idplanning'];

    switch($action){
       case "sup" : $unControleur->deletePlanning($idplanning); break;
       break;
    }
 }

?>
