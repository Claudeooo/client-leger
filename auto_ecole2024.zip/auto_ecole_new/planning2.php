
<?php
require_once ("vue/vue.planning2.php");

if(isset($_POST['Valider'])){
    $unControleur->insertPlanning ($_POST);
   }

?>
