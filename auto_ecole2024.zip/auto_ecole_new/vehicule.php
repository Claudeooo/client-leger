<?php
require_once('vue/vue.vehicule.php');


if(isset($_POST['Valider'])){
    $unControleur->insertVehicule ($_POST);
   }


   if(isset($_GET['action']) && isset($_GET['idvehicule'])){
    $action = $_GET['action'];
    $idvehicule = $_GET['idvehicule'];

    switch($action){
       case "sup" : $unControleur->deleteVehicule($idvehicule); break;
       case "edit" : $laClasse = $unControleur->selectWhereClasse($idclasse); 
       //var_dump($laClasse);


       break;

    }
 }
?>