<?php   session_start();
	require_once("controleur/controleur.class.php"); 
	//instanciation du controleur 
	$unControleur = new Controleur (); 
  $lesEtudiants = $unControleur->selectAllCandidat();
  $lesMoniteurs = $unControleur->selectAllMoniteur();
  $lesPlannings = $unControleur->selectAllPlanning();
  $LesLecons = $unControleur->selectAllLecon(); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Planning</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body style="background-image: url('images/fond2.jpg');">
<?php include('layout/navbar-admin.php');?>

   <div style="padding:200px"> 
    <center>
        <h3>Planning </h3>
    </center>
    <form method="post">
        <div class="mb-3">
            <label style="color:white;" for="exampleInputEmail1" class="form-label">Date/Heure de debut</label>
            <input type="datetime-local" name="DATEHEURDEBUR" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            <div style="color:white;" class="form-text">Exemple : 01/12/2023 15:00</div>
        </div>
        <div class="mb-3">
            <label style="color:white;" for="exampleInputEmail1" class="form-label">Date/Heure de fin</label>
            <input type="datetime-local" name="DATEFINHEUR" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp">
            <div style="color:white;" class="form-text">Exemple : 01/12/2023 15:00</div>
        </div>
        <label style="color:white;" for="exampleInputEmail1" class="form-label">Lecon</label>
            <select class="form-select" aria-label="Default select example" name="IDLECON">
            <option selected>Lecon</option>
            <?php
            if (isset($LesLecons)){
                
                foreach ($LesLecons as $uneLecon){
                    echo "<option value=".$uneLecon['IDLECON'].">".$uneLecon['TITRE']."</option>";
                }
            }
            ?>
            </select>
        <label style="color:white;" for="exampleInputEmail1" class="form-label">Candidat</label>
        <select class="form-select" aria-label="Default select example" name="IDUSER_1">
            <option selected>Candidat</option>
            <?php
            if (isset($lesEtudiants)){
                foreach ($lesEtudiants as $unEtudiant){
                    echo "<option value=".$unEtudiant['IDUSER'].">".$unEtudiant['NOM']."</option>";
                }
            }
            ?>
        </select>
                    <br>

                <label style="color:white;" for="exampleInputEmail1" class="form-label">Moniteur</label>
                <select class="form-select" aria-label="Default select example" name="IDUSER_2">
            <option selected>Moniteur</option>
            <?php
            if (isset($lesMoniteurs)){
                foreach ($lesMoniteurs as $unMoniteur){
                    echo "<option value=".$unMoniteur['IDUSER']." >".$unMoniteur['NOM']."</option>";
                }
            }
            ?>
        </select>
        <br>
        <label style="color:white;" for="exampleInputEmail1" class="form-label">Etat</label>
            <select class="form-select" aria-label="Default select example" name="ETAT">
                <option >Validé </option>
                <option>Annule </option> 
                <option>En attente</option>
            </select>
            <br>
 
        <button type="submit" name="Valider" class="btn btn-primary">Valider</button>
    </form>
    <div>
        <br><br>
        <table class="table table-dark table-striped-columns">
        <td>Date/Heure de debut</td>
        <td> Date/Heure de fin </td>
        <td> Candidat </td>
        <td> Moniteur </td>
        <td> Etat </td>
        <td> Action </td>
    </tr>
    <?php
         if (isset($lesPlannings)){
            foreach ($lesPlannings as $unPlanning){
                echo "<tr>";
                echo "<td>".$unPlanning['DATEHEURDEBUR']."</td>";
                echo "<td>".$unPlanning['DATEFINHEUR']."</td>";
                echo "<td>".$unPlanning['IDUSER_1']."</td>";
                echo "<td>".$unPlanning['IDUSER_2']."</td>";
                echo "<td>".$unPlanning['ETAT']."</td>";
                echo '<td><a href="planning.php?action=sup&idplanning='.$unPlanning['IDPLANNING'].'">Supprimer</a></td>';
                echo "</tr>";
            }
        }
        ?>
</body>
</html>