<?php
session_start();
	require_once("controleur/controleur.class.php"); 
	//instanciation du controleur 
	$unControleur = new Controleur (); 
  $lesVehicules = $unControleur->selectAllVehicule();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vehicule</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>
<body style="background-image: url('images/fond2.jpg');">
<?php
include('layout/navbar-admin.php');
?>

<center>

<br><br> <h1> Ajouter un vehicule </h1><br><br>
    <form method="post">
        <input type="text" name="marque" placeholder="Marque">
        <input type="text" name="modele" placeholder="Modele">
        <input type="text" name="immatriculation" placeholder="immatriculation">
        <input type="submit" name="Valider" class="btn btn-primary">
    </form>


<h3> Liste des vehicule </h3>
<table border="1" class="table table-dark table-striped-columns">
    <tr>
        <td> Marque  </td>
        <td> Modele </td>
        <td> Immatriculation </td>
        <td> </td>
    </tr>
    <?php
    if (isset($lesVehicules)){
        foreach ($lesVehicules as $unVehicule){
            echo "<tr>";
            echo "<td>".$unVehicule['MARQUE']."</td>";
            echo "<td>".$unVehicule['MODELE']."</td>";
            echo "<td>".$unVehicule['IMMATRICULATION'].'</td>';
           echo '<td><a href="vehicule.php?action=sup&idvehicule='.$unVehicule['IDVEHICULE'].' class="btn btn-danger">Supprimer</a></td>';
            echo "</tr>";

            
        }
    }
    ?>
   
    </center>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>